export const nav = [
    {
      id: 1,
      text: "home",
      url: "/",
    },
    {
      id: 2,
      text: "taarabot",
      url:"https://mediafiles.botpress.cloud/5778def2-9ee0-4b3f-990f-97f5df404e60/webchat/bot.html",
    },
    {
      id: 3,
      text: "blog",
      url: "/pages",
    },
    {
      id: 4,
      text: "Shelter",
      url: "/shelter",
    },
    {
      id: 5,
      text: "Job",
      url: "/jobs",
    },
  ]
  export const category = [
    {
      id: 1,
      category: "",
      title: "Stay Calm And Surf",
      cover: "../images/category/ca1.png",
    },
    {
      id: 2,
      category: "",
      title: "Becoming a Dragonfly",
      cover: "../images/category/ca2.png",
    },
    {
      id: 3,
      category: "",
      title: "There's always light at the end of the tunnel",
      cover: "../images/category/ca3.png",
    },
    {
      id: 4,
      category: "Sport",
      title: "Stay Calm And Surf",
      cover: "../images/category/ca4.png",
    },
    {
      id: 5,
      category: "Fun",
      title: "There's always light at the end of the tunnel",
      cover: "../images/category/ca5.png",
    },
    {
      id: 6,
      category: "Health",
      title: "Becoming a Dragonfly",
      cover: "../images/category/ca6.png",
    },
    {
      id: 7,
      category: "Business",
      title: "Stay Calm And Surf",
      cover: "../images/category/ca7.png",
    },
    {
      id: 8,
      category: "Technology",
      title: "There's always light at the end of the tunnel",
      cover: "../images/category/ca8.png",
    },
  ]